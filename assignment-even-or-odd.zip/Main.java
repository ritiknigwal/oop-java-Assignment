//Even or odd 



public class Main
{
	public static void main(String[] args) {
	   
	    int n = 13;
		
		
		if(n%2==0){
		    		System.out.println("even no");

		}
		else{
		    		System.out.println("odd no");

		}
	}
}