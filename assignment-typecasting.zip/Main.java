//#typecasting 
//int to double
//double to int

public class Main
{
	public static void main(String[] args) {
	    
	    
	    int a = 10;
	    double b = a;
		System.out.println(b);
		
		double x = 11.0;
		int y = (int)x;
		System.out.print(y);
	}
}